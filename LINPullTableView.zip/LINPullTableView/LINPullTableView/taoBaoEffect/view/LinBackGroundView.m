//
//  LinBackGroundView.m
//  LINPullTableView
//
//  Created by earnestLin on 2019/1/11.
//  Copyright © 2019年 earnestLin. All rights reserved.
//

#import "LinBackGroundView.h"

@implementation LinBackGroundView

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    return nil;
}

@end
