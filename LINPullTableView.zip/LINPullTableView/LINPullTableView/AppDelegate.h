//
//  AppDelegate.h
//  LINPullTableView
//
//  Created by earnestLin on 2019/1/9.
//  Copyright © 2019年 earnestLin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

